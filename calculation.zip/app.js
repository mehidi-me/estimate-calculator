// let noOfDropship = 100,
//   itemVarient = 2,
//   apparelQ = 2,
//   nonApparelQ = 4,
//   printQ = 0,
//   boxPrice = 3.95,
//   itemVarientCharge = 1,
//   perItemCost = 0.65,
//   perItemPrint = 0.55,
//   sorting = 0.55,
//   folding = 0.55,
//   recivingCharge = 75,
//   adminCharge = 125;

// apparelTotal = (sorting + folding + perItemCost) * apparelQ + itemVarientCharge;
// nonToal = perItemCost * nonApparelQ + itemVarientCharge;
// printToal = perItemPrint * printQ + itemVarientCharge;
// totalCosting =
//   (apparelTotal + nonToal + boxPrice) * noOfDropship +
//   (adminCharge + recivingCharge);
// console.log("Total", apparelTotal);
// console.log(nonToal);
// console.log(totalCosting);

// Define all configurable values at the top for easy modification
const CHARGES = {
  sorting: 0.55,
  folding: 0.55,
  itemVarientChargeDropship: 1,
  itemVarientChargeBulk: 1.5,
  perItemCostDropship: 0.65,
  perItemCostBulk: 1,
  perItemPrint: 0.55,
  recivingCharge: 75,
  adminCharge: 125,
  boxPrices: {
    dropship: { ls10: 2.95, gt10: 3.95, gt20: 4.95 },
    bulkship: { gt10: 6.95, gt20: 8.95 },
  },
};

// Get references to input elements
const calculateBtn = document.getElementById("calculateBtn");
const numOfDropshipInput = document.getElementById("numOfdropship");
const itemVarientInput = document.getElementById("itemVarient");
const apparelQInput = document.getElementById("apparelQ");
const nonApparelQInput = document.getElementById("nonapparelQ");
const printQInput = document.getElementById("printQ");
const sortingCheckbox = document.getElementById("sorting");
const foldingCheckbox = document.getElementById("folding");

// Get references to the box assembly radio buttons
const ls10 = document.getElementById("ls10"); // > 10x10x10
const gt10 = document.getElementById("gt10"); // < 10x10x10
const gt20 = document.getElementById("gt20"); // < 20x20x20

// Get references to the service type radio buttons
const dropshipRadio = document.getElementById("dropship");
const bulkshipRadio = document.getElementById("bulkship");

// Get references to the step wrappers
const step1 = document.getElementById("step1");
const step2 = document.getElementById("step2");
const step3 = document.getElementById("step3");
const listContainer = step2.querySelector(".estimate-breakdown .list");

// Function to toggle the visibility of the destinations input
const addDestinationsInput = () => {
  const destinationsContainer = document.getElementById(
    "destinations-container"
  );
  if (destinationsContainer) {
    destinationsContainer.classList.add("active");
  }
};

const removeDestinationsInput = () => {
  const destinationsContainer = document.getElementById(
    "destinations-container"
  );
  if (destinationsContainer) {
    destinationsContainer.classList.remove("active");
  }
};

// Event listeners for radio buttons
dropshipRadio.addEventListener("change", removeDestinationsInput);
bulkshipRadio.addEventListener("change", addDestinationsInput);

// On page load, check the initial state of the radio buttons
document.addEventListener("DOMContentLoaded", () => {
  // Toggle the visibility based on the initial radio button selection
  if (bulkshipRadio.checked) {
    addDestinationsInput();
  } else {
    removeDestinationsInput();
  }
});

// Calculate and update the estimate breakdown
calculateBtn.addEventListener("click", () => {
  // Retrieve input values
  const noOfDropship = parseInt(numOfDropshipInput.value) || 0;
  const itemVarient = parseInt(itemVarientInput.value) || 0;
  const apparelQ = parseInt(apparelQInput.value) || 0;
  const nonApparelQ = parseInt(nonApparelQInput.value) || 0;
  const printQ = parseInt(printQInput.value) || 0;
  const sorting = sortingCheckbox.checked ? CHARGES.sorting : 0;
  const folding = foldingCheckbox.checked ? CHARGES.folding : 0;
  const isBulkShip = bulkshipRadio.checked;
  const destinations = isBulkShip
    ? parseInt(document.getElementById("destinations")?.value || 1)
    : 1;

  // Determine box price
  let boxPrice;
  if (isBulkShip) {
    boxPrice = gt10.checked
      ? CHARGES.boxPrices.bulkship.gt10
      : CHARGES.boxPrices.bulkship.gt20;
  } else {
    boxPrice = ls10.checked
      ? CHARGES.boxPrices.dropship.ls10
      : gt10.checked
      ? CHARGES.boxPrices.dropship.gt10
      : CHARGES.boxPrices.dropship.gt20;
  }

  // Determine per-item costs
  const itemVarientCharge = isBulkShip
    ? CHARGES.itemVarientChargeBulk
    : CHARGES.itemVarientChargeDropship;
  const perItemCost = isBulkShip
    ? CHARGES.perItemCostBulk
    : CHARGES.perItemCostDropship;

  // Calculate totals
  const apparelTotal =
    apparelQ > 0
      ? (sorting + folding + perItemCost) * apparelQ + itemVarientCharge
      : 0;
  const nonTotal =
    nonApparelQ > 0 ? perItemCost * nonApparelQ + itemVarientCharge : 0;
  const printTotal =
    printQ > 0 ? CHARGES.perItemPrint * printQ + itemVarientCharge : 0;

  // Calculate final cost
  const totalCosting =
    (apparelTotal + nonTotal + boxPrice) * noOfDropship * destinations +
    (CHARGES.adminCharge + CHARGES.recivingCharge);

  // Prepare breakdown data
  const breakdownData = [
    { label: "Service type", value: isBulkShip ? "Bulk Ship" : "Dropshipping" },
    { label: "Number of Dropship", value: noOfDropship },
    { label: "Item variant", value: itemVarient },
    { label: "Apparel quantity", value: apparelQ },
    { label: "Non-Apparel quantity", value: nonApparelQ },
    { label: "Total quantity", value: apparelQ + nonApparelQ },
    { label: "Box type", value: "Standard Box" },
    { label: "Admin charge", value: `$${CHARGES.adminCharge}` },
    { label: "Receiving Charge", value: `$${CHARGES.recivingCharge}` },
    {
      label: "Dropship/Box Assembly",
      value: isBulkShip
        ? gt10.checked
          ? "< 10x10x10"
          : gt20.checked
          ? "< 20x20x20"
          : "Unknown" // Handle case if no box size is selected
        : ls10.checked
        ? "> 10x10x10"
        : gt10.checked
        ? "< 10x10x10"
        : gt20.checked
        ? "< 20x20x20"
        : "Unknown", // Handle case if no box size is selected
    },
  ];

  function updateEstimateBreakdown(data) {
    // Get the list container where the breakdown will be displayed
    const listContainer = document.querySelector(".estimate-breakdown .list");

    // Clear previous contents
    listContainer.innerHTML = "";

    // Loop through the data array and create a block for each breakdown
    data.forEach((item) => {
      const block = document.createElement("div");
      block.classList.add("block-item"); // Optionally add a class for styling

      block.innerHTML = `
      <strong>${item.label}:</strong> ${item.value}
    `;

      listContainer.appendChild(block);
    });
  }

  updateEstimateBreakdown(breakdownData);

  step2.querySelector("h2").textContent = `${totalCosting.toFixed(2)} USD`;
  step1.classList.remove("active");
  step2.classList.add("active");

  // Debugging logs
  console.log("Apparel Total:", apparelTotal);
  console.log("Non-Apparel Total:", nonTotal);
  console.log("Print Total:", printTotal);
  console.log("Total Costing:", totalCosting);
});


document.getElementById("getAQuoteNowBtn").addEventListener("click", () => {
  step2.classList.remove("active");
  step3.classList.add("active");
})


// Get reference to the "meaw" card-wrap and radio buttons
const meawCard = document.querySelector(".card-wrap.meaw");

// Function to toggle active class on meaw card based on selected service type
const toggleActiveCard = () => {
  if (dropshipRadio.checked) {
    meawCard.classList.add("active"); // Add active class if dropship is selected
  } else {
    meawCard.classList.remove("active"); // Remove active class if bulkship is selected
  }
};

// Event listeners for the radio buttons
dropshipRadio.addEventListener("change", toggleActiveCard);
bulkshipRadio.addEventListener("change", toggleActiveCard);

// On page load, ensure the meaw card has the active class by default if dropship is selected
document.addEventListener("DOMContentLoaded", () => {
  if (!dropshipRadio.checked && bulkshipRadio.checked) {
    meawCard.classList.remove("active"); // Remove active if bulkship is selected
  } else {
    meawCard.classList.add("active"); // Ensure meaw card is active by default if dropship is selected
  }
});
let cstm = document.querySelector(".cstm");
function cstmAlrt() {
  cstm.classList.add("active");
}
function RcstmAlrt() {
  cstm.classList.remove("active");
}

// Code 2
// const calculateBtn = document.getElementById("calculateBtn");
// const numOfDropshipInput = document.getElementById("numOfdropship");
// const itemVarientInput = document.getElementById("itemVarient");
// const apparelQInput = document.getElementById("apparelQ");
// const nonApparelQInput = document.getElementById("nonapparelQ");
// const printQInput = document.getElementById("printQ");
// const sortingCheckbox = document.getElementById("sorting");
// const foldingCheckbox = document.getElementById("folding");

// // Get references to the box assembly radio buttons
// const ls10 = document.getElementById("ls10"); // > 10x10x10
// const gt10 = document.getElementById("gt10"); // < 10x10x10
// const gt20 = document.getElementById("gt20"); // < 20x20x20

// // Get references to the service type radio buttons
// const dropshipRadio = document.getElementById("dropship");
// const bulkshipRadio = document.getElementById("bulkship");

// // Get references to the step wrappers
// const step1 = document.getElementById("step1");
// const step2 = document.getElementById("step2");

// // Get references to the estimate breakdown elements in Step 2
// const serviceType = step2.querySelector(".item:nth-child(1) span");
// const numOfDropshipDisplay = step2.querySelector(".item:nth-child(2) span");
// const itemVarientDisplay = step2.querySelector(".item:nth-child(3) span");
// const apparelQDisplay = step2.querySelector(".item:nth-child(4) span");
// const nonApparelQDisplay = step2.querySelector(".item:nth-child(5) span");
// const totalQDisplay = step2.querySelector(".item:nth-child(6) span");
// const boxTypeDisplay = step2.querySelector(".item:nth-child(7) span");
// const boxAssemblyDisplay = step2.querySelector(".item:nth-child(8) span");

// // Get references to elements
// const listContainer = step2.querySelector(".estimate-breakdown .list");

// // Function to update the estimate breakdown list
// const updateEstimateBreakdown = (data) => {
//   // Clear existing list items
//   listContainer.innerHTML = "";

//   // Dynamically create list items
//   data.forEach((item) => {
//     const listItem = document.createElement("p");
//     listItem.className = "item";
//     listItem.innerHTML = `${item.label}: <span>${item.value}</span>`;
//     listContainer.appendChild(listItem);
//   });
// };

// // Function to dynamically add destinations input field
// const addDestinationsInput = () => {
//   const destinationsInput = document.createElement("input");
//   destinationsInput.type = "number";
//   destinationsInput.id = "destinations";
//   destinationsInput.placeholder = "Number of Destinations";
//   destinationsInput.value = 1; // Default value
//   destinationsInput.required = true;

//   // Append the input field to the form
//   const block = document.querySelector(".block");
//   block.appendChild(destinationsInput);
// };

// // Function to remove destinations input field
// const removeDestinationsInput = () => {
//   const destinationsInput = document.getElementById("destinations");
//   if (destinationsInput) {
//     destinationsInput.remove();
//   }
// };

// // Add event listeners to service type radio buttons
// dropshipRadio.addEventListener("change", () => {
//   removeDestinationsInput();
// });

// bulkshipRadio.addEventListener("change", () => {
//   addDestinationsInput();
// });

// // Inside the calculateBtn click event handler:
// calculateBtn.addEventListener("click", () => {
//   // Retrieve values from the input fields
//   const noOfDropship = parseInt(numOfDropshipInput.value) || 0;
//   const itemVarient = parseInt(itemVarientInput.value) || 0;
//   const apparelQ = parseInt(apparelQInput.value) || 0;
//   const nonApparelQ = parseInt(nonApparelQInput.value) || 0;
//   const printQ = parseInt(printQInput.value) || 0;

//   // Check if sorting and folding are selected
//   const sorting = sortingCheckbox.checked ? 0.55 : 0;
//   const folding = foldingCheckbox.checked ? 0.55 : 0;

//   // Determine service type
//   const isBulkShip = bulkshipRadio.checked;

//   // Determine box price and dynamic charges based on user selection
//   let boxPrice, itemVarientCharge, perItemCost;
//   if (isBulkShip) {
//     // Bulk Ship pricing
//     if (gt10.checked) {
//       boxPrice = 6.95; // < 10x10x10
//     } else if (gt20.checked) {
//       boxPrice = 8.95; // < 20x20x20
//     }
//     itemVarientCharge = 1.5; // Increased charge for Bulk Ship
//     perItemCost = 1; // Increased cost for Bulk Ship
//   } else {
//     // Dropship pricing
//     if (ls10.checked) {
//       boxPrice = 2.95; // > 10x10x10
//     } else if (gt10.checked) {
//       boxPrice = 3.95; // < 10x10x10
//     } else if (gt20.checked) {
//       boxPrice = 4.95; // < 20x20x20
//     }
//     itemVarientCharge = 1; // Default charge
//     perItemCost = 0.65; // Default cost
//   }

//   // Constants for pricing
//   const perItemPrint = 0.55;
//   const recivingCharge = 75;
//   const adminCharge = 125;

//   // Calculate apparel total
//   const apparelTotal =
//     (sorting + folding + perItemCost) * apparelQ + itemVarientCharge;

//   // Calculate non-apparel total
//   const nonTotal = perItemCost * nonApparelQ + itemVarientCharge;

//   // Calculate print total
//   const printTotal = perItemPrint * printQ + itemVarientCharge;

//   // Calculate total costing
//   let totalCosting;
//   if (isBulkShip) {
//     const destinations = parseInt(document.getElementById("destinations").value) || 1;
//     totalCosting =
//       (apparelTotal + nonTotal + boxPrice) * noOfDropship * destinations +
//       (adminCharge + recivingCharge);
//   } else {
//     totalCosting =
//       (apparelTotal + nonTotal + boxPrice) * noOfDropship +
//       (adminCharge + recivingCharge);
//   }

//   // Log the results to the console
//   console.log("Apparel Total:", apparelTotal);
//   console.log("Non-Apparel Total:", nonTotal);
//   console.log("Print Total:", printTotal);
//   console.log("Total Costing:", totalCosting);

//   // Prepare dynamic data for the breakdown
//   const breakdownData = [
//     { label: "Service type", value: isBulkShip ? "Bulk Ship" : "Dropshipping" },
//     { label: "Number of Dropship", value: noOfDropship },
//     { label: "Item variant", value: itemVarient },
//     { label: "Apparel quantity", value: apparelQ },
//     { label: "Non-Apparel quantity", value: nonApparelQ },
//     { label: "Total quantity", value: apparelQ + nonApparelQ },
//     { label: "Box type", value: "Standard Box" },
//     { label: "Admin charge", value: "$" + adminCharge },
//     { label: "Reciving Charge", value: "$" + recivingCharge },
//     {
//       label: "Dropship/Box Assembly",
//       value: isBulkShip
//         ? gt10.checked
//           ? "< 10x10x10"
//           : "< 20x20x20"
//         : ls10.checked
//         ? "> 10x10x10"
//         : gt10.checked
//         ? "< 10x10x10"
//         : "< 20x20x20",
//     },
//   ];

//   // Update the list dynamically
//   updateEstimateBreakdown(breakdownData);

//   // Update the total estimate price
//   const estimatePrice = step2.querySelector("h2");
//   estimatePrice.textContent = `${totalCosting.toFixed(2)} USD`;

//   // Move to Step 2
//   step1.classList.remove("active");
//   step2.classList.add("active");
// });
